#!/bin/bash
export PORT=8080
export DATABASE_URL="sosb4282_singgah_pos:b1nt@nG9@tcp(localhost:3306)/sosb4282_singgah_pos?charset=utf8mb4&parseTime=True&loc=Local"
export JWT_SECRET="sg7#pL8*RnY4&xWzB3!cFjT1@hN6eAd5"
export NODE_ENV=production
export GOMAXPROCS=1
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$SCRIPT_DIR/singgah-backend" ]; then
    cd "$SCRIPT_DIR" && exec ./singgah-backend
elif [ -f "$SCRIPT_DIR/backend/singgah-backend" ]; then
    cd "$SCRIPT_DIR" && exec ./backend/singgah-backend
fi
echo "ERROR: singgah-backend binary not found" && exit 1
